# MediCure-WebApplication
1.  index.html is the main Page of our WebApplication and along with that style.css is the css file of our webapplication and main.js is the Javascript file which contains the API of the images.
2.  login.html is the login page which contains both logins for the customers as well as for the store owners it consist of inline css and inline javascript written
in the html file itself.\
3.  map.html is the html file which is for the option of Set your Location only Google API is needed else everything is done designing part also done.
4.  offers.html, offers.css are the pages made for the offers section.
5.  pres.html, pres.css aree the prescription upload section files.
